#include<iostream>
using namespace std;
template<class T>
T& Compare(T& a,T& b){
	return a>b? a: b;
}
int main(){
	int no=98,nt=78;
	double dw=19.14,ds=74.84;
	string a="iop",b="gyu";
	cout<<Compare(no,nt)<<endl;
	cout<<Compare(dw,ds)<<endl;
	cout<<Compare(a,b);
	return 0;
}
