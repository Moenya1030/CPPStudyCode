#include<iostream>
using namespace std;
class Person{
	public:
		void SetName(char *name){
			int j=0;
			for(int i=0;name[i]!='\0'&&i<10;i++){
				this->name[j]=name[i];
				j++;
			}
		}
		char* GetName(){return name;}
		void PrintInfo(){
			for(int i=0;name[i]!='\0'&&i<10;i++)
			 cout<<name[i];
			cout<<endl;
		}
	private:
		char name[10];
};
class Student:public Person{
	public:
		void SetNum(int number){this->number=number;}
		int GetNum(){return number;}
		void PrintInfo(){
			char *name=GetName();
			for(int i=0;name[i]!='\0'&&i<10;i++)
			 cout<<name[i];
			cout<<" "<<number;
		}
	private:
		int number;		
};

int main()
{
	Person p;
	Student s;
	p.SetName("����");
	p.PrintInfo();
	s.SetName("����");
	s.SetNum(20192005);
	s.PrintInfo();
	return 0;
}
