class Point
{
	public:
		void a(double xx,double yy);
		double distance(Point &p1,Point &p2);
		double area(Point &p1,Point &p2,Point &p3);
	private:
		double x,y;
};
